import org.springframework.web.bind.annotation.*;
import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;

@RestController
@RequestMapping("/api")
public class DiskUsageController {

    // Endpoint to get disk usage and client info
    @PostMapping("/disk-usage")
    public DiskUsageResponse getDiskUsageAndClientInfo(@RequestBody ClientInfo clientInfo) {
        // Get disk usage details
        FileSystem fs = FileSystems.getDefault();
        File root = fs.getPath("/").toFile();  // You can adjust for specific root directories (like C: on Windows)

        long totalSpace = root.getTotalSpace();  // Total space in bytes
        long freeSpace = root.getFreeSpace();   // Free space in bytes
        long usedSpace = totalSpace - freeSpace;

        // Convert bytes to GB
        double totalGB = totalSpace / (1024.0 * 1024 * 1024);
        double usedGB = usedSpace / (1024.0 * 1024 * 1024);
        double freeGB = freeSpace / (1024.0 * 1024 * 1024);
        double percentageUsed = (usedGB / totalGB) * 100;

        // Create and return response
        return new DiskUsageResponse(
                new DiskUsage(totalGB, usedGB, freeGB, percentageUsed),
                clientInfo
        );
    }
}

// Response model class for disk usage
class DiskUsage {
    private double total;
    private double used;
    private double free;
    private double percentageUsed;

    // Constructor, getters and setters
    public DiskUsage(double total, double used, double free, double percentageUsed) {
        this.total = total;
        this.used = used;
        this.free = free;
        this.percentageUsed = percentageUsed;
    }

    public double getTotal() {
        return total;
    }

    public double getUsed() {
        return used;
    }

    public double getFree() {
        return free;
    }

    public double getPercentageUsed() {
        return percentageUsed;
    }
}

// Client info model class
class ClientInfo {
    private String os;
    private String architecture;
    private String browser;

    // Constructor, getters, and setters
    public ClientInfo(String os, String architecture, String browser) {
        this.os = os;
        this.architecture = architecture;
        this.browser = browser;
    }

    public String getOs() {
        return os;
    }

    public String getArchitecture() {
        return architecture;
    }

    public String getBrowser() {
        return browser;
    }
}

// Response class containing both disk usage and client info
class DiskUsageResponse {
    private DiskUsage disk;
    private ClientInfo clientInfo;

    // Constructor, getters, and setters
    public DiskUsageResponse(DiskUsage disk, ClientInfo clientInfo) {
        this.disk = disk;
        this.clientInfo = clientInfo;
    }

    public DiskUsage getDisk() {
        return disk;
    }

    public ClientInfo getClientInfo() {
        return clientInfo;
    }
}
